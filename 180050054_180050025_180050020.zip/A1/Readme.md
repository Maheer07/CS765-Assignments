Download the directory and go to folder A1
Run model_program.py by the command python3 model_program.py
After the above execution you'll be able to see the tree files for each peer in the network